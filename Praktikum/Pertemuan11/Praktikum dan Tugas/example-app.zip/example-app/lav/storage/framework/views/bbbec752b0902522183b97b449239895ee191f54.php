<!
DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/css/bootstrap.min.css" integrity="sha512-T584yQ/tdRR5QwOpfvDfVQUidzfgc2339Lc8uBDtcp/wYu80d7jwBgAxbyMh0a9YM9F8N3tdErpFI8iaGx6x5g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container">

        <?php if(session('pesan')): ?>
            <div class="alert alert-success">
                <?php echo e(session('pesan')); ?>

            </div>
        <?php endif; ?>

        <table class="table">
            <tr>
                <td>
                    #
                </td>
                <td>
                    NIM
                </td>
                <td>
                    Name
                </td>
                <td>
                    Gender
                </td>
                <td>
                    Jurusan
                </td>
                <td>
                    Alamat
                </td>
                <td>
                    Aksi
                </td>
            </tr>

            <?php
                $no = 1
            ?>

            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($no++); ?>

                    </td>
                    <td>
                        <?php echo e($s->nim); ?>

                    </td>
                    <td>
                        <?php echo e($s->name); ?>

                    </td>
                    <td>
                        <?php echo e($s->gender); ?>

                    </td>
                    <td>
                        <?php echo e($s->department); ?>

                    </td>
                    <td>
                        <?php echo e($s->address); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(url('/mahasiswa/'.$s->id.'/edit')); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(url('/mahasiswa/hapus/'.$s->id)); ?>" method="POST" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\LENOVO\OneDrive\Dokumen\19104030 - Html\Praktikum\Pertemuan9\Praktikum dan Tugas\example-app\resources\views/student.blade.php ENDPATH**/ ?>