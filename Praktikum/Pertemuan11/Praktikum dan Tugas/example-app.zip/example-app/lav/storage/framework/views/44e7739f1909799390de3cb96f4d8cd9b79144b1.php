<?php $__env->startSection('content'); ?>
    <h1>About</h1>
    <p>Ini adalah Praktikum pemrograman web yang mempelajari Framework Laravel yaitu PHP</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive\Dokumen\19104030 - Html\Praktikum\Pertemuan8\Praktikum_dan_Tugas\example-app\resources\views/template/about.blade.php ENDPATH**/ ?>