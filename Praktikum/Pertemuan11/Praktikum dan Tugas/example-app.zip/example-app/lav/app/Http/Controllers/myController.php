<?php
// membuat controller sendiri

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class myController extends Controller
{
    public function index(){
        return view('beranda');
    }
}
